# Finance Dashboard Backend

## Description
This project is a backend application built using Spring Boot for managing financial records such as income and expenses.

## Features
- User registration and login 
- CRUD operations for financial records
- MySQL database integration
- REST APIs tested using Postman
- Swagger API documentation

## Technologies Used
- Java 17
- Spring Boot
- Spring Security
- MySQL
- JPA (Hibernate)

## How to Run
1. Clone the project
2. Open in Spring Tool Suite / IntelliJ
3. Configure MySQL in application.properties
4. Run the application

## API Testing
Use Postman to test APIs:
- POST /api/users
- GET /api/users
- POST /api/login
- GET /api/records

## Swagger
http://localhost:8080/swagger-ui.html