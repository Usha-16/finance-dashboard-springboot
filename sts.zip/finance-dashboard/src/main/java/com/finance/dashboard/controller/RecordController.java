package com.finance.dashboard.controller;

import com.finance.dashboard.model.Record;
import com.finance.dashboard.service.RecordService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/records")
public class RecordController {

    private final RecordService recordService;

    public RecordController(RecordService recordService) {
        this.recordService = recordService;
    }

    @PostMapping
    public Record createRecord(@RequestBody Record record) {
        return recordService.createRecord(record);
    }

    @GetMapping
    public List<Record> getAllRecords() {
        return recordService.getAllRecords();
    }

    @GetMapping("/category/{category}")
    public List<Record> getRecordsByCategory(@PathVariable String category) {
        return recordService.getRecordsByCategory(category);
    }

    @GetMapping("/date/{date}")
    public List<Record> getRecordsByDate(@PathVariable String date) {
        return recordService.getRecordsByDate(LocalDate.parse(date));
    }

    @DeleteMapping("/{id}")
    public void deleteRecord(@PathVariable Long id) {
        recordService.deleteRecord(id);
    }
}
