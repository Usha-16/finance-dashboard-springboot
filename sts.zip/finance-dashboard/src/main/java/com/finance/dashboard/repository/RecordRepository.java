package com.finance.dashboard.repository;

import com.finance.dashboard.model.Record;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface RecordRepository extends JpaRepository<Record, Long> {
    List<Record> findByCategory(String category);
    List<Record> findByDate(LocalDate date);
    List<Record> findByType(String type);
}
