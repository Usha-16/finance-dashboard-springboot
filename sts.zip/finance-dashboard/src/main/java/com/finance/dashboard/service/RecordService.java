package com.finance.dashboard.service;

import com.finance.dashboard.model.Record;
import com.finance.dashboard.repository.RecordRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class RecordService {
    private final RecordRepository recordRepository;

    public RecordService(RecordRepository recordRepository) {
        this.recordRepository = recordRepository;
    }

    public Record createRecord(Record record) {
        return recordRepository.save(record);
    }

    public List<Record> getAllRecords() {
        return recordRepository.findAll();
    }

    public List<Record> getRecordsByCategory(String category) {
        return recordRepository.findByCategory(category);
    }

    public List<Record> getRecordsByDate(LocalDate date) {
        return recordRepository.findByDate(date);
    }

    public void deleteRecord(Long id) {
        recordRepository.deleteById(id);
    }
}
